package com.mindtree.MilestoneFive;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MilestoneFiveApplication {

	public static void main(String[] args) {
		SpringApplication.run(MilestoneFiveApplication.class, args);
	}

}
